<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "TMPro";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// إعادة تعيين العداد
$sql = "UPDATE detection_counter SET count = 0 WHERE id = 1";
$conn->query($sql);

echo "Counter Reset"; // تأكيد إعادة التعيين

$conn->close();
?>
