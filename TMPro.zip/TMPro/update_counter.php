<?php
$servername = "localhost"; // غيّره حسب إعدادات السيرفر
$username = "root"; // ضع اسم المستخدم الصحيح
$password = ""; // ضع كلمة المرور الصحيحة
$dbname = "TMPro";

// إنشاء الاتصال
$conn = new mysqli($servername, $username, $password, $dbname);

// التحقق من الاتصال
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// تحديث العداد
$sql = "UPDATE detection_counter SET count = count + 1 WHERE id = 1";
$conn->query($sql);

// جلب العدد الجديد
$result = $conn->query("SELECT count FROM detection_counter WHERE id = 1");
$row = $result->fetch_assoc();

echo $row['count']; // إرسال العدد إلى JavaScript

$conn->close();
?>
