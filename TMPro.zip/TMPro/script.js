let model;
let detectionCount = 0;

const video = document.getElementById("webcam");
const startCameraButton = document.getElementById("startCamera");
const captureButton = document.getElementById("capturePredict");
const resultText = document.getElementById("result");
const detectionCounter = document.getElementById("detectionCount");
const capturedImage = document.getElementById("capturedImage");
const resetCounterButton = document.getElementById("resetCounter");

// رابط النموذج من Teachable Machine
const URL = "https://teachablemachine.withgoogle.com/models/ATu0M2RFa/";

// تحميل النموذج

async function loadModel() {
    try {
      const modelURL = URL + "model.json";
      const metadataURL = URL + "metadata.json";
      console.log("Attempting to load model from:", modelURL);
      model = await tmImage.load(modelURL, metadataURL);
      console.log("Model loaded successfully!");
    } catch (error) {
      console.error("Failed to load model!", error);
      resultText.innerText = "Failed to load model! Check console for details.";
    }
  }
  

// تشغيل الكاميرا عند الضغط على الزر
startCameraButton.addEventListener("click", () => {
  navigator.mediaDevices.getUserMedia({ video: true })
    .then(stream => {
      video.srcObject = stream;
      console.log("Camera started successfully");
    })
    .catch(err => {
      console.error("Error accessing webcam:", err);
      resultText.innerText = "Failed to access camera!";
    });
});

// التقاط صورة وتحليلها عند الضغط على الزر
captureButton.addEventListener("click", async () => {
  if (!model) {
    resultText.innerText = "Model not loaded!";
    return;
  }

  // إنشاء canvas لالتقاط الصورة من الكاميرا
  const canvas = document.createElement("canvas");
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  const ctx = canvas.getContext("2d");
  ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

  // عرض الصورة الملتقطة
  const imageURL = canvas.toDataURL("image/png");
  capturedImage.src = imageURL;

  // إجراء التنبؤ باستخدام النموذج
  const prediction = await model.predict(canvas);
  const highestPrediction = prediction.reduce((prev, curr) =>
    prev.probability > curr.probability ? prev : curr
  );

  resultText.innerText = `Prediction: ${highestPrediction.className} (${(highestPrediction.probability * 100).toFixed(2)}%)`;
  detectionCount++;
  detectionCounter.innerText = detectionCount;
});

// إعادة تعيين العداد عند الضغط على الزر
resetCounterButton.addEventListener("click", () => {
  detectionCount = 0;
  detectionCounter.innerText = detectionCount;
});

// تحميل النموذج عند بدء تشغيل الصفحة
loadModel();
